#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <algorithm>
#include <windows.h>

using namespace std;

const int MAX_IDS = 3000;  // Adjusted for demonstration purposes

struct UserData {
    string data;
};

struct MessageData {
    int id;
    string userData;
};

int generateRandomID() {
    return rand() % MAX_IDS + 1;
}

// Function to perform Caesar Cipher encryption
string encryptCaesarCipher(const string& plainText, int shift) {
    string cipherText = "";
    for (char ch : plainText) {
        if (isalpha(ch)) {
            char base = isupper(ch) ? 'A' : 'a';
            cipherText += static_cast<char>((ch - base + shift) % 26 + base);
        } else {
            cipherText += ch;
        }
    }
    return cipherText;
}

// Function to send a message to the server with encryption
void SendMessageToServer(vector<MessageData>& messages, int encryptionShift) {
    srand(static_cast<unsigned int>(time(nullptr)));

    string userData;
    cout << "\nEnter data: ";
    cin.ignore();
    getline(cin, userData);

    int id = generateRandomID();

    string encryptedData = encryptCaesarCipher(userData, encryptionShift);

    // Display entered data, assigned key, and encrypted data
    cout << "Entered data: " << userData << endl;
    cout << "Assigned Key: " << id << endl;
    cout << "Encrypted data: " << encryptedData << endl;

    // Create a MessageData struct and add it to the vector
    MessageData message;
    message.id = id;
    message.userData = encryptedData;

    messages.push_back(message);

    // Display message sent to the server (encrypted)
    cout << "Message sent to the server (encrypted): " << encryptedData << " with Key: " << id << endl;
}

// Function to perform Caesar Cipher decryption
string decryptCaesarCipher(const string& cipherText, int shift) {
    return encryptCaesarCipher(cipherText, 26 - shift);
}

// Function to retrieve a message from the server and decrypt it
void RetrieveMessageById(const vector<MessageData>& messages, int id, int encryptionShift) {
    auto it = find_if(messages.begin(), messages.end(), [id](const MessageData& message) {
        return message.id == id;
    });

    if (it != messages.end()) {
        // Display retrieved message data and decrypted user data
        cout << "\nRetrieved Message Data:" << endl;
        cout << "User ID: " << it->id << endl;
        cout << "Decrypted User Data: " << decryptCaesarCipher(it->userData, encryptionShift) << endl;
    } else {
        // Display a message if the message with the specified key is not found
        cout << "Message with Key " << id << " not found." << endl;
    }
}

// Function to display all stored messages
void DisplayAllMessages(const vector<MessageData>& messages, int encryptionShift) {
    cout << "\nAll stored messages:" << endl;
    for (const auto& message : messages) {
        // Display user ID and decrypted user data for each message
        cout << "User ID: " << message.id << endl;
        cout << "Decrypted User Data: " << decryptCaesarCipher(message.userData, encryptionShift) << endl;
        cout << "--------------------------" << endl;
    }
}

// Function to perform user login
bool PerformLogin() {
    string userID, password;
    cout << "\nWelcome to the Admin panel \nSend your data to the server or retrieve from server" << endl;
    cout << "Please log in to continue.\n";
    cout << "Enter User ID: ";
    cin >> userID;

    HANDLE hInput = GetStdHandle(STD_INPUT_HANDLE);
    DWORD mode;
    GetConsoleMode(hInput, &mode);
    SetConsoleMode(hInput, mode & (~ENABLE_ECHO_INPUT));
    cout << "Enter password: ";
    cin >> password;
    SetConsoleMode(hInput, mode);

    // Check if the provided credentials are valid
    return (userID == "admin" && password == "236");
}

// Main function
int main() {
    int choice;
    vector<MessageData> messages;
    int encryptionShift = 3;  // Caesar Cipher shift (adjust as needed)

    do {
    	cout << "--------------------------" << endl;
        cout << "Send Your Message To Server\nOr \nRetierve Message From Server \nMenu:\n1. Send Message to Server\n2. Retrieve Message from Server\n";
        cout << "3. Display Message by Key\n4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                SendMessageToServer(messages, encryptionShift);
                break;

            case 2:
                int idToRetrieve;
                cout << "Enter Key to retrieve: ";
                cin >> idToRetrieve;
                RetrieveMessageById(messages, idToRetrieve, encryptionShift);
                break;

            case 3:
                if (!PerformLogin()) {
                    cout << "Login failed. Exiting the program." << endl;
                    return 1;
                }
                DisplayAllMessages(messages, encryptionShift);
                break;

            case 4:
                cout << "Exiting the program. Goodbye!" << endl;
                break;

            default:
                cout << "Invalid choice. Please try again." << endl;
        }

    } while (choice != 4);

    return 0;
}
