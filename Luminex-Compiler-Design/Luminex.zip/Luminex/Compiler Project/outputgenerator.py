class OutputGenerator:
    def __init__(self, tokens, symbol_table):
        self.tokens = tokens
        self.symbol_table = symbol_table
        self.memory = {}

    def generate_output(self):
        output = ""
        for token in self.tokens:
            if token.type == 'KEYWORD' and token.value == 'var':
                var_name = self.tokens[self.tokens.index(token) + 2].value
                var_type = self.tokens[self.tokens.index(token) + 3].value
                var_value = self.tokens[self.tokens.index(token) + 5].value
                self.memory[var_name] = var_value
                output += f"Variable declared: {var_name} = {var_value}\n"
            elif token.type == 'IDENTIFIER' and self.tokens[self.tokens.index(token) + 1].type == 'ASSIGN':
                var_name = token.value
                var_value = self.tokens[self.tokens.index(token) + 2].value
                self.memory[var_name] = var_value
                output += f"Variable updated: {var_name} = {var_value}\n"
            elif token.type == 'KEYWORD' and token.value == 'func':
                output += "Function execution not supported in this mock-up.\n"
        output += "\nOUTPUT:\n"
        for var in self.memory:
            output += f"{var}: {self.memory[var]}\n"
        return output
