from lexical_analyzer import lex, SymbolTable
from syntax_analyzer import Token, SyntaxAnalyzer
from semantic_analyzer import SemanticAnalyzer
def main():

    # lexical analyzer

    tokens, symbol_table = lex(code)

    print("Tokens:")
    for token in tokens:
        print(token)

    print("\nSymbol Table:")
    print(symbol_table)


    # syntax analyzer

    analyzer = SyntaxAnalyzer(tokens, symbol_table);
    results = analyzer.parse();


    print("Syntax Analysis Results:")
    for result, message in results:
        print(message);


    # semantic analyzer

    semantic_analyzer = SemanticAnalyzer(tokens, symbol_table)
    semantic_results = semantic_analyzer.analyze()
    print("\nSemantic Analysis Results:")
    if not semantic_results:
        print("No errors")
    else:
        for message in semantic_results:
            print(message)

if __name__ == "__main__":
    main()
