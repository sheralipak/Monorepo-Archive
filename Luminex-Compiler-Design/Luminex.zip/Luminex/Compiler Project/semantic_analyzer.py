class SemanticAnalyzer:
    def __init__(self, tokens, symbol_table):
        self.tokens = tokens
        self.symbol_table = symbol_table

    def analyze(self):
        results = []
        i = 0
        while i < len(self.tokens):
            token = self.tokens[i]
            if token.type == 'KEYWORD' and token.value == 'var':
                declaration_result = self.check_declaration(i)
                if declaration_result:
                    results.append(declaration_result)
                i += 5  
            elif token.type == 'IDENTIFIER':
                    usage_result = self.check_variable_usage(token)
                    if usage_result:
                        results.append(usage_result)
            i += 1
        return results

    def check_declaration(self, index):
       
        datatype = self.tokens[index + 3].value
        variable_name = self.tokens[index + 2].value
        assignment_operator = self.tokens[index + 4].type
        value_token = self.tokens[index + 5]

        existing_entry = self.symbol_table.lookup(variable_name)
        if existing_entry:
            if existing_entry['Type'] != datatype and existing_entry['Entry Type'] == 'variable':
                return f"Semantic Error: Variable '{variable_name}' already declared with type '{existing_entry['Type']}' at line {existing_entry['Line of Declaration']}"

        
        if assignment_operator == 'ASSIGN':
            if datatype == 'num' and value_token.type != 'NUMERIC_LITERAL':
                return f"Semantic Error: Variable '{variable_name}' of type 'num' assigned non-numeric value '{value_token.value}' at line {value_token.line}"
            elif datatype == 'str' and value_token.type != 'STRING_LITERAL':
                return f"Semantic Error: Variable '{variable_name}' of type 'str' assigned non-string value '{value_token.value}' at line {value_token.line}"
            elif datatype == 'boolit' and value_token.type != 'BOOL_LITERAL':
                return f"Semantic Error: Variable '{variable_name}' of type 'boolit' assigned non-boolean value '{value_token.value}' at line {value_token.line}"
            elif datatype == 'dec' and value_token.type != 'FLOAT_LITERAL':
                return f"Semantic Error: Variable '{variable_name}' of type 'dec' assigned non-float value '{value_token.value}' at line {value_token.line}"
            elif datatype == 'charact' and not (value_token.type == 'STRING_LITERAL' and len(value_token.value) == 3):
                return f"Semantic Error: Variable '{variable_name}' of type 'charact' assigned non-character value '{value_token.value}' at line {value_token.line}"
            
        return None

    def check_variable_usage(self, token):
        variable_name = token.value
        entry = self.symbol_table.lookup(variable_name)
        if not entry:
            return f"Semantic Error: Variable '{variable_name}' not declared before use at line {token.line}"
        elif entry['Entry Type'] != 'variable':
            return None
        return None

