import re
from tabulate import tabulate

class Token:
    def __init__(self, line, type, value):
        self.line = line
        self.type = type
        self.value = value

    def __repr__(self):
        return f"Token({self.line}, {self.type}, {self.value})"

# Token definitions
token_definition = {
    'KEYWORD': r'\b(?:when|otherwise|otherwisewhen|func|var|repeat|for)\b',
    'DATA_TYPE': r'\b(?:num|dec|str|boolit|charact)\b',
    'ARITHMETIC_OPERATOR': r'[\+\-\*\/]',
    'COMPARISON_OPERATOR': r'(?:<|>|==|!=|<=|>=)',
    'LOGICAL_OPERATOR': r'&&',
    'INCREMENT': r'\+\+',
    'DECREMENT': r'\-\-',
    'IDENTIFIER': r'[_a-zA-Z][_a-zA-Z0-9]*',
    'STRING_LITERAL': r'\".*?\"',
    'FLOAT_LITERAL': r'\b\d+\.\d*\b',
    'NUMERIC_LITERAL': r'\b\d+\b',
    'BOOL_LITERAL': r'\b(?:true|false)\b',
    'ASSIGN': r'=',
    'LCURLY': r'{',
    'RCURLY': r'}',
    'LPAREN': r'\(',
    'RPAREN': r'\)',
    'SEPARATOR': r'\,',
    'STATEMENT_END': r'\;',
    'COLON': r'\:',
    'NEWLINE': r'\n',
    'ARROW': r'=>'
}

patterns = {token: re.compile(pattern) for token, pattern in token_definition.items()}

class SymbolTable:
    def __init__(self):
        self.table = []

    def add_entry(self, name, type, line, usage=None, entry_type='variable'):
        entry = {
            'Name': name,
            'Type': type,
            'Line of Declaration': line,
            'Line of Usage': usage,
            'Address': len(self.table) + 1,
            'Entry Type': entry_type
        }
        self.table.append(entry)

    def update_usage(self, name, line):
        for entry in self.table:
            if entry['Name'] == name:
                entry['Line of Usage'] = line

    def lookup(self, name):
        """Retrieve an entry from the symbol table by name."""
        for entry in self.table:
            if entry['Name'] == name:
                return entry
        return None


    def get_all_entries(self):
        return self.table            

    def __str__(self):
        headers = ["Name", "Type", "Line of Declaration", "Line of Usage", "Address", "Entry Type"]
        rows = [[entry['Name'], entry['Type'], entry['Line of Declaration'],
                 entry['Line of Usage'], entry['Address'], entry['Entry Type']] for entry in self.table]
        return tabulate(rows, headers, tablefmt='plain')

def determine_literal_type(value):
    if re.match(token_definition['STRING_LITERAL'], value):
        return 'STRING_LITERAL'
    elif re.match(token_definition['FLOAT_LITERAL'], value):
        return 'FLOAT_LITERAL'
    elif re.match(token_definition['NUMERIC_LITERAL'], value):
        return 'NUMERIC_LITERAL'
    elif re.match(token_definition['BOOL_LITERAL'], value):
        return 'BOOL_LITERAL'
    return 'UNKNOWN'

def lex_line(line, line_number, symbol_table):
    tokens = []
    while line:
        match = None
        for token_type, pattern in token_definition.items():
            regex = re.compile(pattern)
            match = regex.match(line)
            if match:
                value = match.group(0)
                if token_type == 'KEYWORD' and value == 'func':
                    tokens.append(Token(line_number, token_type, value))
                    line = line[match.end():].strip()
                    id_match = re.match(r'[a-zA-Z_]\w*', line)
                    if id_match:
                        function_name = id_match.group(0)
                        tokens.append(Token(line_number, 'IDENTIFIER', function_name))
                        symbol_table.add_entry(function_name, 'function', line_number, entry_type='function')
                        line = line[id_match.end():].strip()
                    arrow_match = re.match(r'=>', line)
                    if arrow_match:
                        tokens.append(Token(line_number, 'ARROW', '=>'))
                        line = line[arrow_match.end():].strip()
                    param_match = re.match(r'\(', line)
                    if param_match:
                        tokens.append(Token(line_number, 'LPAREN', '('))
                        line = line[param_match.end():].strip()
                        while line and not line.startswith(')'):
                            param_match = re.match(r'var\s*:\s*([a-zA-Z_]\w*)\s*(num|dec|str|boolit|charact)', line)
                            if param_match:
                                param_name, param_type = param_match.groups()
                                tokens.append(Token(line_number, 'KEYWORD', 'var'))
                                tokens.append(Token(line_number, 'COLON', ':'))
                                tokens.append(Token(line_number, 'IDENTIFIER', param_name))
                                tokens.append(Token(line_number, 'DATA_TYPE', param_type))
                                symbol_table.add_entry(param_name, param_type, line_number)
                                line = line[param_match.end():].strip()
                                if line.startswith(','):
                                    tokens.append(Token(line_number, 'SEPARATOR', ','))
                                    line = line[1:].strip()
                            else:
                                break
                        rparen_match = re.match(r'\)', line)
                        if rparen_match:
                            tokens.append(Token(line_number, 'RPAREN', ')'))
                            line = line[rparen_match.end():].strip()
                    continue
                elif token_type == 'KEYWORD' and value == 'var':
                    tokens.append(Token(line_number, token_type, value))
                    line = line[match.end():].strip()
                    colon_match = re.match(r':', line)
                    if colon_match:
                        tokens.append(Token(line_number, 'COLON', ':'))
                        line = line[colon_match.end():].strip()
                        id_match = re.match(r'[a-zA-Z_]\w*', line)
                        if id_match:
                            identifier = id_match.group(0)
                            tokens.append(Token(line_number, 'IDENTIFIER', identifier))
                            line = line[id_match.end():].strip()
                            type_match = None
                            for dt_type in ['num', 'dec', 'str', 'boolit', 'charact']:
                                type_match = re.match(r'\b' + dt_type + r'\b', line)
                                if type_match:
                                    tokens.append(Token(line_number, 'DATA_TYPE', dt_type))
                                    line = line[type_match.end():].strip()
                                    symbol_table.add_entry(identifier, dt_type, line_number)
                                    break
                            if type_match:
                                assign_match = re.match(r'=', line)
                                if assign_match:
                                    tokens.append(Token(line_number, 'ASSIGN', '='))
                                    line = line[assign_match.end():].strip()
                                    literal_match = re.match(r'\".*?\"|\d+\.\d*|\d+|true|false', line)
                                    if literal_match:
                                        literal_value = literal_match.group(0)
                                        literal_type = determine_literal_type(literal_value)
                                        tokens.append(Token(line_number, literal_type, literal_value))
                                        line = line[literal_match.end():].strip()
                                        symbol_table.update_usage(identifier, line_number)
                                    statement_end_match = re.match(r'\;', line)
                                    if statement_end_match:
                                        tokens.append(Token(line_number, 'STATEMENT_END', ';'))
                                        line = line[statement_end_match.end():].strip()
                                    continue
                elif token_type == 'IDENTIFIER':
                    symbol_table.update_usage(value, line_number)
                if token_type != 'WHITESPACE' and token_type != 'NEWLINE':
                    tokens.append(Token(line_number, token_type, value))
                line = line[match.end():]
                break
        if not match:
            print(f"Invalid token on line {line_number}: {line}")
            break
    return tokens

def lex(code):
    tokens = []
    line_number = 1
    symbol_table = SymbolTable()
    for line in code.split('\n'):
        line = line.strip()
        if line:
            try:
                tokens.extend(lex_line(line, line_number, symbol_table))
            except ValueError as ve:
                print(f"Error processing line {line_number}: {line}")
                raise ve
        line_number += 1
    return tokens, symbol_table