class Token:
    def __init__(self, line, type, value):
        self.line = line
        self.type = type
        self.value = value

class SyntaxAnalyzer:
    def __init__(self, tokens, symbol_table=None):
        self.tokens = tokens
        self.pos = 0
        self.symbol_table = symbol_table

    def current_token(self):
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def next_token(self):
        self.pos += 1
        return self.current_token()

    def expect(self, expected_type, expected_value=None):
        token = self.current_token()
        if not token:
            raise SyntaxError(f"Unexpected end of input. Expected {expected_type} {expected_value}")

        if token.type != expected_type or (expected_value and token.value != expected_value):
            expected = expected_value if expected_value else expected_type
            raise SyntaxError(f"Expected {expected} at line {token.line}, got {token.value}")

        self.pos += 1
        return token

    def match(self, expected_type, expected_value=None):
        token = self.current_token()
        if not token:
            return False
        return token.type == expected_type and (expected_value is None or token.value == expected_value)

    def analyze_statement(self):
        statement_type = self.identify_statement_type()
        if statement_type == 'declaration':
            return self.analyze_declaration()
        elif statement_type == 'when_statement':
            return self.analyze_condition()
        elif statement_type == 'repeat_loop':
            return self.analyze_repeat_loop()
        elif statement_type == 'function':
            return self.analyze_function_statement()
        elif statement_type == 'assign':
            return self.analyze_assignment()
        elif statement_type == 'function_call':
            return self.analyze_function_call()
        else:
            raise SyntaxError(f"Syntax error: Unexpected statement at line {self.current_token().line}")

    def identify_statement_type(self):
        token = self.current_token()
        if token:
            if token.type == 'KEYWORD':
                if token.value == 'when':
                    return 'when_statement'
                elif token.value == 'repeat':
                    return 'repeat_loop'
                elif token.value == 'func':
                    return 'function'
                elif token.value == 'var':
                    return 'declaration'
            elif token.type == 'IDENTIFIER':
                next_token = self.tokens[self.pos + 1] if self.pos + 1 < len(self.tokens) else None
                if next_token and next_token.type == 'LPAREN':
                    return 'function_call' 
                else:
                    return 'assign'   
            # elif token.type == 'IDENTIFIER':
            #     return 'assign'    
        return 'unknown'

    def analyze_declaration(self):
        try:
            self.expect('KEYWORD', 'var')
            self.expect('COLON')
            self.expect('IDENTIFIER')
            self.expect('DATA_TYPE')
            self.expect('ASSIGN')
            if not self.expression():
                raise SyntaxError(f"Syntax Error: Invalid expression after assignment operator at line {self.current_token().line}")
            self.expect('STATEMENT_END')
            return True, "Declaration and initialzation statement is correct"
        except SyntaxError as e:
            return False, str(e)
        

    def analyze_condition(self):
        try:
            self.expect('KEYWORD', 'when')
            self.expect('LPAREN')
            self.analyze_condition_block()
            self.expect('RPAREN')
            self.expect('LCURLY')
            self.analyze_block()
            self.expect('RCURLY')


            while self.match('KEYWORD', 'otherwisewhen') or self.match('KEYWORD', 'otherwise'):
                if self.match('KEYWORD', 'otherwisewhen'):
                    self.next_token() 
                    self.expect('LPAREN')
                    self.analyze_condition_block()
                    self.expect('RPAREN')
                    self.expect('LCURLY')
                    self.analyze_block()
                    self.expect('RCURLY')
                elif self.match('KEYWORD', 'otherwise'):
                    self.next_token()  
                    self.expect('LCURLY')
                    self.analyze_block()
                    self.expect('RCURLY')

          
            return True, "Conditional statement is correct"
        except SyntaxError as e:
            return False, str(e)

    def analyze_assignment(self):
        try:
            self.expect('IDENTIFIER')
            self.expect('ASSIGN')
            self.expression()
            self.expect('STATEMENT_END')
            return True, "Assignment statement is correct"
        except SyntaxError as e:
            return False, f"Syntax Error: {str(e)}"

    def expression(self):
        valid_types = ['NUMERIC_LITERAL', 'ARITHMETIC_OPERATOR', 'FLOAT_LITERAL', 'COMPARISON', 'STRING_LITERAL', 'BOOL_LITERAL', 'IDENTIFIER']
        if self.current_token() and self.current_token().type in valid_types:
            self.pos += 1
            while self.current_token() and self.current_token().type in valid_types:
                self.pos += 1
            return True
        else:
            raise SyntaxError(f"Syntax error: Invalid expression at line {self.current_token().line}")

    def skip_to_statement_end(self):
        while self.current_token() and self.current_token().type != 'STATEMENT_END':
            self.next_token()
        self.next_token() 

    def parse(self):
        results = []
        while self.pos < len(self.tokens):
            statement_type = self.identify_statement_type()
            if statement_type == 'declaration':
                result, message = self.analyze_declaration()
            elif statement_type == 'when_statement':
                result, message = self.analyze_condition()
            elif statement_type == 'assign':
                result, message = self.analyze_assignment()
            elif statement_type == 'repeat_loop':
                result, message = self.analyze_repeat_loop()
            elif statement_type == 'function':
                result, message = self.analyze_function_statement()
            elif statement_type == 'function_call':
                result, message = self.analyze_function_call()
            else:
                self.skip_to_statement_end()
                result = False
                message = f"Unexpected statement at line {self.current_token().line if self.current_token() else 'EOF'}"
            results.append((result, message))
        return results

    def analyze_repeat_loop(self):
        try:
            self.expect('KEYWORD', 'repeat')
            self.expect('LPAREN')
            self.analyze_condition_block() 
            self.expect('RPAREN')
            self.expect('LCURLY')
            self.analyze_block()  
            self.expect('RCURLY')
            return True, "repeat loop statement is correct"
        except SyntaxError as e:
            return False, str(e)

    def analyze_condition_block(self):
        self.expect('IDENTIFIER')
        self.expect('COMPARISON_OPERATOR')
        self.expect('NUMERIC_LITERAL')

    def analyze_iteration_block(self):
        if self.match('IDENTIFIER'):
            self.expect('IDENTIFIER')
            if self.match('INCREMENT'):
                self.expect('INCREMENT')
            elif self.match('DECREMENT'):
                self.expect('DECREMENT')
            else:
                raise SyntaxError(f"Unexpected token in iteration block at line {self.current_token().line}")

    def analyze_block(self):
        while not self.match('RCURLY'):
            self.expect('IDENTIFIER')
            self.expect('ASSIGN')
            if self.match('STRING_LITERAL'):
                self.expect('STRING_LITERAL')
            elif self.match('FLAOT_LITERAL'):
                self.expect('FLOAT_LITERAL')
            elif self.match('NUMERIC_LITERAL'):
                self.expect('NUMERIC_LITERAL')
            elif self.match('BOOL_LITERAL'):
                self.expect('BOOL_LITERAL')
            else:
                raise SyntaxError(f"Unexpected token at line {self.tokens[self.pos].line}")
            self.expect('STATEMENT_END')

    def analyze_function_statement(self):
        try:
            self.expect('KEYWORD', 'func')
            self.expect('IDENTIFIER')
            self.expect('ARROW')  
            self.expect('LPAREN')
            self.analyze_parameter_block() 
            self.expect('RPAREN')
            self.expect('LCURLY')
            self.analyze_block()  # Analyze the then block
            self.expect('RCURLY')
            return True, "Function statement is correct"
        except SyntaxError as e:
            return False, str(e)

    def analyze_parameter_block(self):
        while not self.match('RPAREN'):
            self.expect('KEYWORD', 'var')
            self.expect('COLON')
            self.expect('IDENTIFIER')
            self.expect('DATA_TYPE')
            if self.match('SEPARATOR'):
                self.expect('SEPARATOR')


    def analyze_function_call(self):
        try:
            self.expect('IDENTIFIER')  # Function name
            self.expect('LPAREN')
            if not self.match('RPAREN'):
                self.analyze_arguments()
            self.expect('RPAREN')
            self.expect('STATEMENT_END')
            return True, "Function call is correct"
        except SyntaxError as e:
            return False, str(e)
        

    def analyze_arguments(self):
        while True:
            if self.match('STRING_LITERAL'):
                self.expect('STRING_LITERAL')
            elif self.match('NUMERIC_LITERAL'):
                self.expect('NUMERIC_LITERAL')
            elif self.match('FLOAT_LITERAL'):
                self.expect('FLOAT_LITERAL')
            elif self.match('IDENTIFIER'):
                self.expect('IDENTIFIER')
            else:
                raise SyntaxError(f"Unexpected token in function arguments at line {self.current_token().line}")
            if self.match('SEPARATOR', ','):
                self.next_token()  
            else:
                break