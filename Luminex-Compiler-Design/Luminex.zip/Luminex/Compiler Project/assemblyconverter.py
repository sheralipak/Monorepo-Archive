class AssemblyConverter:
    def __init__(self, tokens):
        self.tokens = tokens

    def convert(self):
        assembly_code = ""
        for token in self.tokens:
            if token.type == 'KEYWORD' and token.value == 'var':
                assembly_code += f"DECLARE {token.value}\n"
            elif token.type == 'IDENTIFIER':
                assembly_code += f"LOAD {token.value}\n"
            elif token.type == 'ASSIGN':
                assembly_code += "STORE\n"
            elif token.type == 'NUMERIC_LITERAL' or token.type == 'STRING_LITERAL':
                assembly_code += f"MOV {token.value}\n"
        return assembly_code
