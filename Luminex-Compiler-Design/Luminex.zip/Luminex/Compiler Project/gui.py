import tkinter as tk
from tkinter import scrolledtext, font, Toplevel
from lexical_analyzer import lex, SymbolTable
from syntax_analyzer import Token, SyntaxAnalyzer
from semantic_analyzer import SemanticAnalyzer
from assemblyconverter import AssemblyConverter
from outputgenerator import OutputGenerator  # Import the output generator

class CompilerGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Luminex Compiler")

        # Setting the theme colors
        self.bg_color = "#1e1e1e"
        self.text_color = "#dcdcdc"
        self.button_color = "#007acc"
        self.button_text_color = "#ffffff"
        self.font_style = font.Font(family="Consolas", size=12)
        self.button_font_style = font.Font(family="Consolas", size=10, weight="bold")

        self.root.configure(bg=self.bg_color)

        self.header_label = tk.Label(root, text="Luminex Compiler", bg=self.bg_color, fg=self.button_color, font=("Consolas", 20, "bold"))
        self.header_label.pack(pady=10)

        self.main_frame = tk.Frame(root, bg=self.bg_color)
        self.main_frame.pack(padx=10, pady=5, fill=tk.BOTH, expand=True)

        self.editor_label = tk.Label(self.main_frame, text="Editor", bg=self.bg_color, fg=self.text_color, font=self.font_style)
        self.editor_label.grid(row=0, column=0, padx=5, pady=5, sticky="w")

        self.output_label = tk.Label(self.main_frame, text="Output", bg=self.bg_color, fg=self.text_color, font=self.font_style)
        self.output_label.grid(row=0, column=1, padx=5, pady=5, sticky="w")

        self.errors_label = tk.Label(self.main_frame, text="Results", bg=self.bg_color, fg=self.text_color, font=self.font_style)
        self.errors_label.grid(row=0, column=2, padx=5, pady=5, sticky="w")

        self.code_text = scrolledtext.ScrolledText(self.main_frame, width=50, height=20, bg="#252526", fg=self.text_color, insertbackground=self.text_color, font=self.font_style, borderwidth=0)
        self.code_text.grid(row=1, column=0, padx=5, pady=5, sticky="nsew")

        self.output_text = scrolledtext.ScrolledText(self.main_frame, width=50, height=10, bg="#252526", fg=self.text_color, insertbackground=self.text_color, font=self.font_style, borderwidth=0)
        self.output_text.grid(row=1, column=1, padx=5, pady=5, sticky="nsew")

        self.errors_text = scrolledtext.ScrolledText(self.main_frame, width=50, height=10, bg="#252526", fg=self.text_color, insertbackground=self.text_color, font=self.font_style, borderwidth=0)
        self.errors_text.grid(row=1, column=2, padx=5, pady=5, sticky="nsew")

        self.main_frame.grid_columnconfigure(0, weight=1)
        self.main_frame.grid_columnconfigure(1, weight=1)
        self.main_frame.grid_columnconfigure(2, weight=1)
        self.main_frame.grid_rowconfigure(1, weight=1)

        self.button_frame = tk.Frame(root, bg=self.bg_color)
        self.button_frame.pack(pady=10)

        self.run_button = tk.Button(self.button_frame, text="Run", command=self.run_code, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.run_button.pack(side=tk.LEFT, padx=5)

        self.compile_button = tk.Button(self.button_frame, text="Compile", command=self.compile_code, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.compile_button.pack(side=tk.LEFT, padx=5)

        self.symbol_table_button = tk.Button(self.button_frame, text="Symbol Table", command=self.show_symbol_table, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.symbol_table_button.pack(side=tk.LEFT, padx=5)

        self.assembly_code_button = tk.Button(self.button_frame, text="Assembly Code", command=self.show_assembly_code, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.assembly_code_button.pack(side=tk.LEFT, padx=5)

        self.clear_code_button = tk.Button(self.button_frame, text="Clear Code", command=self.clear_code, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.clear_code_button.pack(side=tk.LEFT, padx=5)

        self.clear_output_button = tk.Button(self.button_frame, text="Clear Output", command=self.clear_output, bg=self.button_color, fg=self.button_text_color, font=self.button_font_style)
        self.clear_output_button.pack(side=tk.LEFT, padx=5)


    def run_code(self):
        self.errors_text.delete("1.0", tk.END)
        self.output_text.delete("1.0", tk.END)
        code = self.code_text.get("1.0", tk.END)
        tokens, symbol_table = lex(code)
        analyzer = SyntaxAnalyzer(tokens, symbol_table)
        results = analyzer.parse()
        semantic_analyzer = SemanticAnalyzer(tokens, symbol_table)
        semantic_results = semantic_analyzer.analyze()

        for result, message in results:
            self.errors_text.insert(tk.END, f"{message}\n")
        for message in semantic_results:
            self.errors_text.insert(tk.END, f"{message}\n")

        if not results and not semantic_results:
            generator = OutputGenerator(tokens, symbol_table)
            output = generator.generate_output()
            self.output_text.insert(tk.END, output)

    def compile_code(self):
        self.errors_text.delete("1.0", tk.END)
        self.output_text.delete("1.0", tk.END)
        code = self.code_text.get("1.0", tk.END)
        tokens, symbol_table = lex(code)
        generator = OutputGenerator(tokens, symbol_table)
        output = generator.generate_output()
        self.output_text.insert(tk.END, output)

    def show_symbol_table(self):
        code = self.code_text.get("1.0", tk.END)
        tokens, symbol_table = lex(code)
        symbol_table_window = Toplevel(self.root)
        symbol_table_window.title("Symbol Table")
        symbol_table_window.configure(bg=self.bg_color)
        text_area = scrolledtext.ScrolledText(symbol_table_window, width=80, height=20, bg="#252526", fg=self.text_color, insertbackground=self.text_color, font=self.font_style, borderwidth=0)
        text_area.pack(padx=10, pady=10)
        text_area.insert(tk.END, str(symbol_table))

    def show_assembly_code(self):
        code = self.code_text.get("1.0", tk.END)
        tokens, symbol_table = lex(code)
        converter = AssemblyConverter(tokens)
        assembly_code = converter.convert()
        assembly_code_window = Toplevel(self.root)
        assembly_code_window.title("Assembly Code")
        assembly_code_window.configure(bg=self.bg_color)
        text_area = scrolledtext.ScrolledText(assembly_code_window, width=80, height=20, bg="#252526", fg=self.text_color, insertbackground=self.text_color, font=self.font_style, borderwidth=0)
        text_area.pack(padx=10, pady=10)
        text_area.insert(tk.END, assembly_code)

    def clear_code(self):
        self.code_text.delete("1.0", tk.END)

    def clear_output(self):
        self.output_text.delete("1.0", tk.END)
        self.errors_text.delete("1.0", tk.END)


if __name__ == "__main__":
    root = tk.Tk()
    gui = CompilerGUI(root)
    root.mainloop()
